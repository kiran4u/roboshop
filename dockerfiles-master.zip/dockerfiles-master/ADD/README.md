### ADD
ADD is same as COPY. It is useful to copy files from local to container. But it has 2 extra capabilities.

1. ADD can download the file directly from internet to the container.
2. ADD can untar/unzip the file directly into the container.