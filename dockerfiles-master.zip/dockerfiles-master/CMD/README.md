### CMD

CMD is the instruction that runs the container. It should run in foreground and it should run for infinite time.

### RUN vs CMD

* RUN command will execute at the time of image creation.
* CMD command will execute at the time of running container.