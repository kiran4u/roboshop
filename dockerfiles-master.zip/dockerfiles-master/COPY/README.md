### COPY

COPY instruction is useful to copy the files from local to image.

### try
```
docker run -d -p 80:80 techworldwithsiva/copy:v1
```