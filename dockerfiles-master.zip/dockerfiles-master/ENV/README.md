### ENV

ENV is the instruction to provide environment variables to image and container. You can override env variables at runtime