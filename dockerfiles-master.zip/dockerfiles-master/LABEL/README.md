### LABEL

LABEL instruction is useful to give some metadata information. 