### WORKDIR

WORKDIR is used to set the path to the image while creating.